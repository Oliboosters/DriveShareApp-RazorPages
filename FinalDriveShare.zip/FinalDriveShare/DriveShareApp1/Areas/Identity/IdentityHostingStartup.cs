﻿using System;
using DriveShareApp1.Areas.Identity.Data;
using DriveShareApp1.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(DriveShareApp1.Areas.Identity.IdentityHostingStartup))]
namespace DriveShareApp1.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<DriveShareadContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("DriveShareadContextConnection")));

                services.AddDefaultIdentity<DriveShareUser>(options =>
                {
                    options.SignIn.RequireConfirmedAccount = false;
                    options.Password.RequireUppercase = false;
                    options.Password.RequireLowercase = false;
                    options.Password.RequireNonAlphanumeric = false;
                })
                    .AddEntityFrameworkStores<DriveShareadContext>();
            });
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace DriveShareApp1.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the DriveShareUser class
    public class DriveShareUser : IdentityUser
    {
        [PersonalData]
        [Column(TypeName ="nvarchar(50)")]
        public string FullName { get; set; }

        [PersonalData]
        [Column(TypeName = "nvarchar(MAX)")]
        public string PhoneNumber { get; set; }    
    }
}

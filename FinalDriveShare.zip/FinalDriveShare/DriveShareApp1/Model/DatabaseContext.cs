﻿using Microsoft.EntityFrameworkCore;

namespace DriveShareApp1.Model
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options): base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PassengerTable>().HasKey(p => new { p.AppointmentID, p.JoinedUserId });
        }

        public DbSet<Carpool> Appointments { get; set; }

        public DbSet<PassengerTable> PassengerTable { get; set; }
    }
}

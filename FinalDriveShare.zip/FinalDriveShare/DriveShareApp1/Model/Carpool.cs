﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DriveShareApp1.Model
{
    public class Carpool
    {
        [Key]  
        public int AppointmentID { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Start Address")]
        public string StartAddress { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "End Address")]
        public string EndAddress { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        [Display(Name = "Time of departure")]
        public DateTime TimeOfDeparture { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Estimated time of arrival")]
        public DateTime TimeOfArrival { get; set; }

        [Required]
        [StringLength(1, ErrorMessage = "Please enter a valid number.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        [Display(Name = "Available Seats")]
        public string AvailableSeats { get; set; }
        
        public int BookedSeats { get; set; }
             
        [Display(Name = "Driver")]
        public string Driver { get; set; }
        
        [DataType(DataType.Text)]
        [Display(Name = "Extra Comments")]
        public string ExtraComments { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "To School/From School")]
        public string ToOrFromSchool { get; set; }
        
    }
}

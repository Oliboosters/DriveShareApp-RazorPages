﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DriveShareApp1.Model
{
    public class PassengerTable
    {
        [Key, Column(Order = 0)]
        public int AppointmentID { get; set; }

        [Key, Column(Order = 1)]
        public string JoinedUserId { get; set; }

    }
}

using DriveShareApp1.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;

namespace DriveShareApp1.Pages
{
    public class CarpoolModel : PageModel
    {
        private readonly UserManager<DriveShareUser> _userManager;
        private readonly SignInManager<DriveShareUser> _signInManager;

        DatabaseContext Context;

        public CarpoolModel(DatabaseContext databasecontext, UserManager<DriveShareUser> userManager, SignInManager<DriveShareUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            Context = databasecontext;
        }

        [BindProperty]
        public Carpool Carpool { get; set; }
        
        public string WelcomeMessage { get; set; }

        public void OnGet()
        {
            WelcomeMessage = "Make a New Carpool";
        }

        public ActionResult OnPost(string ori)
        {
            var c = Carpool;

            if (!ModelState.IsValid)
            {
                return Page(); //Returns Current Page if the typed information is incorrect
            }

            c.Driver = _userManager.GetUserAsync(User).Result.Id;
            c.AppointmentID = 0;
            var result = Context.Add(c);
            Context.SaveChanges(); //Data wiil now be saved in database

            return RedirectToPage(ori);
        }       
    }
}
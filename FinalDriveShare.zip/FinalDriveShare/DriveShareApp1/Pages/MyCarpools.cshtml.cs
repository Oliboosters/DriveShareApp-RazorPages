using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DriveShareApp1.Model;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;

namespace DriveShareApp1.Pages
{
    public class MyCarpoolsModel : PageModel
    {
        private readonly UserManager<DriveShareUser> _userManager;
        private readonly SignInManager<DriveShareUser> _signInManager;

        DatabaseContext Context;

        public MyCarpoolsModel(DatabaseContext databasecontext, UserManager<DriveShareUser> userManager, SignInManager<DriveShareUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            Context = databasecontext;
        }

        public UserManager<DriveShareUser> UserManager => _userManager;

        public List<Carpool> CarpoolList { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchCriteria { get; set; }

        [BindProperty]
        public string SearchSelection { get; set; }

        public void OnGet()
        {
            var allData = from carpoollist in Context.Appointments select carpoollist;

            CarpoolList = allData.ToList();
        }

        public ActionResult OnPost()
        {
            var data = from carpoollist in Context.Appointments select carpoollist;

            if (!string.IsNullOrEmpty(SearchCriteria))
            {
                switch (SearchSelection)
                {
                    case "Start_Address":

                        data = Context.Appointments.Where(c => c.StartAddress.ToLower().Contains(SearchCriteria.ToLower()));

                        break;

                    case "End_Address":

                        data = Context.Appointments.Where(c => c.EndAddress.ToLower().Contains(SearchCriteria.ToLower()));

                        break;

                    case "Available_Seats":

                        data = Context.Appointments.Where(c => c.AvailableSeats.ToLower().Contains(SearchCriteria.ToLower()));

                        break;

                    case "To_Or_From_School":

                        data = Context.Appointments.Where(c => c.ToOrFromSchool.ToLower().Contains(SearchCriteria.ToLower()));

                        break;

                    default:

                        break;
                }
            }

            CarpoolList = data.ToList();

            return Page();
        }
    }
}

using System.Linq;
using DriveShareApp1.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DriveShareApp1.Pages
{
    public class CarpoolDetailsModel : PageModel
    {
        DatabaseContext Context;
        public CarpoolDetailsModel(DatabaseContext databasecontext)
        {
            Context = databasecontext;
        }

        [BindProperty]
        public Carpool Carpool { get; set; }

        public ActionResult OnGet(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Carpool = Context.Appointments.FirstOrDefault(c => c.AppointmentID == id);

            if (Carpool == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}

using System.Collections.Generic;
using System.Linq;
using DriveShareApp1.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DriveShareApp1.Pages
{
    public class DeleteCarpoolModel : PageModel
    {
        DatabaseContext Context;
        //Initialisere databasen
        public DeleteCarpoolModel(DatabaseContext databasecontext)
        {
            Context = databasecontext;
        }

        [BindProperty]
        public Carpool Carpool { get; set; }
        public List<PassengerTable> PassengerList { get; set; }

        public ActionResult OnGet(int? id)
        {
            if(id == null)
            {
                return NotFound();
            }

            Carpool = Context.Appointments.FirstOrDefault(c => c.AppointmentID == id);

            if (Carpool == null)
            {
                return NotFound();
            }

            return Page();
        }

        public ActionResult OnPost(int? id, string ori)
        {
            if(id == null)
            {
                return NotFound();
            }

            Carpool = Context.Appointments.Find(id); //Finds the Carpool object with the same id
            var allPassengerData = from passengerlist in Context.PassengerTable select passengerlist;
            PassengerList = allPassengerData.ToList();
            
            if (id != null)
            {
                foreach (var p in PassengerList.Where(p => p.AppointmentID == Carpool.AppointmentID))
                {
                    Context.PassengerTable.Remove(p);
                    Context.SaveChanges();
                }
                Context.Appointments.Remove(Carpool);
                Context.SaveChanges(); //Data wiil now be saved in database
            }

            return RedirectToPage(ori);
        }
    }
}

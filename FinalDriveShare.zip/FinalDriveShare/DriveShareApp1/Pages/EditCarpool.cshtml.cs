using System.Linq;
using DriveShareApp1.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace DriveShareApp1.Pages
{
    public class EditCarpoolModel : PageModel
    {
        private readonly UserManager<DriveShareUser> _userManager;
        private readonly SignInManager<DriveShareUser> _signInManager;

        DatabaseContext Context;

        public EditCarpoolModel(DatabaseContext databasecontext, UserManager<DriveShareUser> userManager, SignInManager<DriveShareUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            Context = databasecontext;
        }

        [BindProperty]
        public Carpool Carpool { get; set; }

        public string Message { get; set; }
        
        public ActionResult OnGet(int? id)
        {
            Message = "Edit Your Carpool";

            if(id == null)
            {
                return NotFound();
            }

            /* Finds the first Carpool in the database where "AppointmentID" matches the passed value "id".
               If no value is found it will just return "Default" (null) */

            Carpool = Context.Appointments.FirstOrDefault(c => c.AppointmentID == id);

            if(Carpool == null)
            {
                return NotFound();
            }

            return Page();
        }

        public ActionResult OnPost(int? id, string ori)
        {
            if(!ModelState.IsValid)
            {
                return Page();
            }
            
            Carpool.Driver = _userManager.GetUserAsync(User).Result.Id;
            Context.Attach(Carpool).State = EntityState.Modified;
            

            try
            {
                Context.SaveChanges();
            }

            catch(DbUpdateConcurrencyException)
            {
                if(!CarpoolExists(Carpool.AppointmentID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            
            return RedirectToPage(ori);
        }

        private bool CarpoolExists(int id)
        {
            return Context.Appointments.Any(c => c.AppointmentID == id);
        }
    }
}

using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DriveShareApp1.Model;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;


namespace DriveShareApp1.Pages
{
    public class LeaveCarpoolModel : PageModel
    {
        private readonly UserManager<DriveShareUser> _userManager;
        private readonly SignInManager<DriveShareUser> _signInManager;

        DatabaseContext Context;

        public LeaveCarpoolModel(DatabaseContext databasecontext, UserManager<DriveShareUser> userManager, SignInManager<DriveShareUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            Context = databasecontext;
        }

        public Carpool Carpool { get; set; }

        [BindProperty]
        public PassengerTable Passenger { get; set; }

        public UserManager<DriveShareUser> UserManager => _userManager;

        public ActionResult OnGet(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Carpool = Context.Appointments.FirstOrDefault(c => c.AppointmentID == id);
            Passenger = Context.PassengerTable.FirstOrDefault(c => c.AppointmentID == id);

            if (Passenger == null)
            {
                return NotFound();
            }

            if (Carpool == null)
            {
                return NotFound();
            }

            return Page();
        }

        public ActionResult OnPost(int? id, string ori)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = UserManager.GetUserAsync(User).Result.Id;

            var Res = Context.PassengerTable.Where(p=>(p.AppointmentID == id && p.JoinedUserId == user)); //Finds the Carpool object with the same id

            if (Res == null || Res.Count() == 0)
            {
                return NotFound();
            }

            Passenger = Res.First();

            Carpool = Context.Appointments.Find(id);

            if (id != null)
            {
                Carpool.BookedSeats--;

                Context.Appointments.Update(Carpool);
                Context.SaveChanges();

                Context.PassengerTable.Remove(Passenger);
                Context.SaveChanges(); //Data wiil now be saved in database
            }

            return RedirectToPage(ori);
        }
        
    }
}

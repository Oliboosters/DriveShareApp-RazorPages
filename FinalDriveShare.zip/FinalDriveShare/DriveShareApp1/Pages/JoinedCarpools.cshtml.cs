using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DriveShareApp1.Model;
using DriveShareApp1.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;

namespace DriveShareApp1.Pages
{
    public class JoinedCarpoolsModel : PageModel
    {
        private readonly UserManager<DriveShareUser> _userManager;
        private readonly SignInManager<DriveShareUser> _signInManager;

        DatabaseContext Context;

        public JoinedCarpoolsModel(DatabaseContext databasecontext, UserManager<DriveShareUser> userManager, SignInManager<DriveShareUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            Context = databasecontext;
        }

        public UserManager<DriveShareUser> UserManager => _userManager;

        public Carpool Carpool { get; set; }

        public List<Carpool> CarpoolList { get; set; }

        public List<PassengerTable> PassengerList { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchCriteria { get; set; }

        [BindProperty]
        public string SearchSelection { get; set; }

        [BindProperty]
        public PassengerTable Passenger { get; set; }

        public void OnGet()
        {
            var allCarpoolData = from carpoollist in Context.Appointments select carpoollist;
            var allPassengerData = from passengerlist in Context.PassengerTable select passengerlist;

            CarpoolList = allCarpoolData.ToList();
            PassengerList = allPassengerData.ToList();
        }

        public ActionResult OnPost(int id)
        {
            var data = from carpoollist in Context.Appointments select carpoollist;

            if (id == 0)
            {
                if (!string.IsNullOrEmpty(SearchCriteria))
                {
                    switch (SearchSelection)
                    {
                        case "Start_Address":

                            data = Context.Appointments.Where(c => c.StartAddress.ToLower().Contains(SearchCriteria.ToLower()));

                            break;

                        case "End_Address":

                            data = Context.Appointments.Where(c => c.EndAddress.ToLower().Contains(SearchCriteria.ToLower()));

                            break;

                        case "Available_Seats":

                            data = Context.Appointments.Where(c => c.AvailableSeats.ToLower().Contains(SearchCriteria.ToLower()));

                            break;

                        case "To_Or_From_School":

                            data = Context.Appointments.Where(c => c.ToOrFromSchool.ToLower().Contains(SearchCriteria.ToLower()));

                            break;

                        default:

                            break;
                    }
                }
            }

            var allPassengerData = from passengerlist in Context.PassengerTable select passengerlist;

            PassengerList = allPassengerData.ToList();
            CarpoolList = data.ToList();
            
            return Page();
        }
    }
}
